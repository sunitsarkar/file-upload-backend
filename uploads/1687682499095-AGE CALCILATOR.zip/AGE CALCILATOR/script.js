

const inputs = document.getElementsByClassName('input');


function calculate() {
    console.log(inputs[0].value);

    let year = 2023 - inputs[2].value;
    let month = 4 - inputs[1].value;
    let day = 24 - inputs[0].value;
    if (day < 0) {
        month -= 1;
        day = 30 - inputs[0].value;
    }

    if (month < 0) {
        year -= 1;
        month = 12 - inputs[1].value;
    }


    const show = document.getElementsByClassName('show');

    const node = document.createElement('h2');
    if (!year || !month || !day) {
        const para = document.createTextNode(` Please Enter valid data for Month Field And Year Field`)
        node.appendChild(para)

    }
    else {
        const para = document.createTextNode(` Your Age is ${year} Years ${month} Months ${day} Days. `)
        node.appendChild(para);

    }


    show[0].appendChild(node)
}